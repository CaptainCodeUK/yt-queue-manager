import './assets/service-worker.ts-BJeM5CSD.js';
