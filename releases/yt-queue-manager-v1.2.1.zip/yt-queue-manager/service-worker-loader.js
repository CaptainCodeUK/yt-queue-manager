import './assets/service-worker.ts--VBOwR-4.js';
